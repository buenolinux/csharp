﻿using MySql.Data.MySqlClient;
using SisVendas.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisVendas.Telas
{
    public partial class FrmVenda : Form
    {
        Usuario usuarioLogado = new Usuario();
        decimal total = 0;

        public FrmVenda(Usuario usu)
        {
            InitializeComponent();
            usuarioLogado = usu;
        }

        private void FrmVenda_Load(object sender, EventArgs e)
        {
            
        }

        private void cbbProduto_DropDownClosed(object sender, EventArgs e)
        {
            
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            
        }

        private void dgvItens_DoubleClick(object sender, EventArgs e)
        {
            
        }

        private void toolStripSalvar_Click(object sender, EventArgs e)
        {
            
        }

        private Boolean VerificaVazio()
        {
            if (cbbCliente.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um cliente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cbbCliente.Focus();
                return false;
            }

            if (cbbProduto.SelectedIndex == -1)
            {
                MessageBox.Show("Selecione um produto", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cbbProduto.Focus();
                return false;
            }

            if (mskQtde.Text == string.Empty) {
                MessageBox.Show("Digite a quantidade", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                mskQtde.Focus();
                return false;
            }

            if (dgvItens.SelectedRows.Count == 0)
            {
                MessageBox.Show("Não há itens adicionados", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                btnAdicionar.Focus();
                return false;
            }
            return true;
        }

        private void Print_PrintPage (object sender, PrintPageEventArgs e)
        {
            //*********************************
            //int UltimoId = Pedido.BuscaId();
            //*********************************

            //Instanciando o objeto gráfico
            Graphics g = e.Graphics;
            //Instanciando o local da imagem
            Image image = Image.FromFile(string.Format("{0}{1}", Application.StartupPath, "\\logo.png"));

            using (Font fontDestaque = new Font("Arial Black", 14),
                        fontPadrao = new Font("Arial", 12),
                        fontData = new Font("Arial", 10))
            {
                //Posicionando o logo
                g.DrawImage(image, 40, 20);
                //Posicionando o titulo
                g.DrawString("SISTEMA DE VENDAS", fontDestaque, Brushes.DarkRed, 100, 30);
                
                //***************************
                //g.DrawString("Pedido número: " + UltimoId, fontDestaque, Brushes.DarkRed, 100, 50);
                //***************************

                //Posicionando o nome do cliente
                g.DrawString("Cliente: " + cbbCliente.Text, fontData, Brushes.Black, 40, 90);

                //Posicionando a data
                string dataAtual = DateTime.Now.ToString("dd/MM/yyyy");
                g.DrawString("Data: " + dataAtual, fontData, Brushes.Black, 40, 110);

                //Criar uma linha divisória
                Pen divisoria = new Pen(Color.Black);
                g.DrawLine(divisoria, 40, 140, 800, 140);

                //Posicionar as legendas
                g.DrawString("Código", fontDestaque, Brushes.Black, 40, 160);
                g.DrawString("Produto", fontDestaque, Brushes.Black, 140, 160);
                g.DrawString("Qtde", fontDestaque, Brushes.Black, 480, 160);
                g.DrawString("Valor", fontDestaque, Brushes.Black, 580, 160);
                g.DrawString("Subtotal", fontDestaque, Brushes.Black, 700, 160);

                //Variável para os conteúdos das próximas linhas
                int linha = 190;

                //Laço para carregar os conteúdos do datagrid
                for (int i = 0; i < dgvItens.RowCount; i++)
                {
                    string Produto = dgvItens.Rows[i].Cells[1].Value.ToString();
                    if (Produto.Length > 35)
                    {
                        Produto = Produto.Substring(0, 35) + "...";
                    }
                    //Definindo alinhamento
                    StringFormat stringFormat = new StringFormat();
                    stringFormat.Alignment = StringAlignment.Far;

                    //Impressão do conteúdo do datagrid
                    g.DrawString(Convert.ToString(dgvItens.Rows[i].Cells[0].Value), fontPadrao, Brushes.Black, 60, linha);
                    g.DrawString(Produto, fontPadrao, Brushes.Black, 140, linha);
                    g.DrawString(Convert.ToString(dgvItens.Rows[i].Cells[2].Value), fontPadrao, Brushes.Black, 500, linha);
                    g.DrawString(Convert.ToString(dgvItens.Rows[i].Cells[3].Value), fontPadrao, Brushes.Black, 640, linha, stringFormat);
                    g.DrawString(Convert.ToString(dgvItens.Rows[i].Cells[4].Value), fontPadrao, Brushes.Black, 788, linha, stringFormat);

                    //Incrementando a linha
                    linha = linha + 25;
                }

                //Linha divisória antes do total
                g.DrawLine(divisoria, 40, (linha + 10), 800, (linha + 10));

                //Impressão do total
                g.DrawString("Total", fontDestaque, Brushes.DarkRed, 580, linha + 20);
                g.DrawString(lblTotal.Text, fontDestaque, Brushes.DarkRed, 700, linha + 20);
            }
        }

        private void toolStripImprimir_Click(object sender, EventArgs e)
        {
            using (PrintDocument print = new PrintDocument())
            using (PrintPreviewDialog dialog = new PrintPreviewDialog())
            {
                print.PrintPage += Print_PrintPage;
                dialog.Document = print;
                dialog.ShowDialog();
                toolStripLimpar.Enabled = true;
            }
        }

        private void dgvPedidos_Click(object sender, EventArgs e)
        {
            
        }

        private void MostraPedido()
        {
            
        }

        private void toolStripLimpar_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripExcluir_Click(object sender, EventArgs e)
        {
            
        }
    }
}
