﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_EnviaEmail
{
    public partial class frmEnviaEmail : Form
    {
        public frmEnviaEmail()
        {
            InitializeComponent();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            if (ValidaDados())
            {
                try
                {
                    btnEnviar.Text = "Enviando...";
                    btnEnviar.Enabled = false;
                    MailMessage mensagem = new MailMessage();
                    SmtpClient smtp = new SmtpClient();
                    mensagem.From = new MailAddress("seu email microsofoth", "André");
                    mensagem.To.Add(txbPara.Text);
                    mensagem.Subject = (txbAssunto.Text);
                    mensagem.Body = (txbMensagem.Text);
                    mensagem.Priority = MailPriority.Normal;

                    smtp.EnableSsl = true;
                    smtp.Port = 587; // Outlook e Hotmail
                    smtp.Host = "smtp.office365.com";
                    smtp.Credentials = new NetworkCredential("seu email microsofoth", txbSenha.Text);
                    smtp.Send(mensagem);

                    MessageBox.Show("Mensagem enviada", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txbPara.Clear();
                    txbAssunto.Clear(); ;
                    txbMensagem.Clear();
                    txbSenha.Clear();

                    btnEnviar.Enabled = true;
                    btnEnviar.Text = "Enviar";


                }
                catch (Exception erro) // variável erro que contém o erro
                {

                    //throw;
                    MessageBox.Show("Erro ao enviar o e-mail" + erro , "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnEnviar.Enabled = true;
                    btnEnviar.Text = "Enviar";
                }
            }
        }

        private bool ValidaDados()
        {
            if(txbPara.Text == "")
            {
                MessageBox.Show("Digite o destinatário", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (txbAssunto.Text == "")
            {
                MessageBox.Show("Digite o assunto", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (txbMensagem.Text == "")
            {
                MessageBox.Show("Digite a mensagem", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (txbSenha.Text == "")
            {
                MessageBox.Show("Digite a senha", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return true;
                 
        }
    }
}
