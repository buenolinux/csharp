﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _04_tabuada
{
    public partial class frmTatuaba : Form
    {
        public frmTatuaba()
        {
            InitializeComponent();
        }

        private void rdbDois_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 2;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbQuatro_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 4;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbSeis_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 6;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbOito_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 8;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbDez_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 10;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (verifica())
            {
                int numero = int.Parse(mskNumero.Text);
                lstResultado.Items.Clear();
                for (int i = 1; i <= 10; i++)
                {
                    lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
                }
            }
        }

        public bool verifica()
        {
            if (mskNumero.Text == string.Empty)
            {
                MessageBox.Show("Digite um numero", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mskNumero.Focus();
                return false;
            }
            
            return true;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskNumero.Clear();
 
            rdbUm.Checked = false;
            rdbDois.Checked = false;
            rdbTres.Checked = false;
            rdbQuatro.Checked = false;
            rdbCinco.Checked = false;
            rdbSeis.Checked = false;
            rdbSete.Checked = false;
            rdbOito.Checked = false;
            rdbNove.Checked = false;
            rdbDez.Checked = false;
            lstResultado.Items.Clear();
            mskNumero.Focus();
        }

        private void rdbUm_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 1;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbTres_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 3;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbCinco_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 5;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbSete_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 7;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbNove_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 9;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }
    }
}
