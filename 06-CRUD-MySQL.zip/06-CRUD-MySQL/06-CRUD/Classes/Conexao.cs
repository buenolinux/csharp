﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_CRUD.Classes
{
    class Conexao
    {
        #region "Variáveis"

        private static string _servidor = @"localhost";
        private static string _baseDeDados = "crud";
        private static string _usuario = "root";
        private static string _senha = "";

        //Linha de conexão para o MySQL
        private static string _strConexao = "Server=" + _servidor + ";Database=" + _baseDeDados + ";Uid=" + _usuario + ";Pwd=" + _senha;

        public string query;
        public MySqlConnection conexao = new MySqlConnection(_strConexao);
        public MySqlCommand comando;
        public MySqlDataReader dr;
        public MySqlDataAdapter da;
        public DataSet ds;

        #endregion


        #region  "Métodos"

        //Método para abrir a conexão
        public void AbreConexao()
        {
            if (conexao.State == ConnectionState.Open)
            {
                conexao.Close();
            }
            conexao.Open();
        }


        //Método para fechar a conexão
        public void FechaConexao()
        {
            if (conexao.State == ConnectionState.Open)
            {
                conexao.Close();
            }
        }

        #endregion
    }
}
