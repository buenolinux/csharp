﻿using _06_CRUD.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _06_CRUD.Telas
{
    public partial class frmPrincipal : Form
    {
        Usuario usuarioLogado = new Usuario();
        public frmPrincipal(Usuario usu)
        {
            InitializeComponent();
            usuarioLogado = usu;
        }
    }
}
