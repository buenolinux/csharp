﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_CRUD.Classes
{
    public class Pessoa
    {
        #region "Variáveis"

        private int _id_pessoa;
        private string _nome;
        private string _email;
        private string _fone;
        private string _dt_nasc;
        private string _sexo;
        private string _foto;
        private int _ativo;

        #endregion


        #region "Propriedades"

        public int Id_pessoa
        {
            get { return _id_pessoa; }
            set { _id_pessoa = value; }
        }

        public string Nome
        {
            get { return _nome; }
            set { _nome = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public string Fone
        {
            get { return _fone; }
            set { _fone = value; }
        }

        public string Dt_nasc
        {
            get { return _dt_nasc; }
            set { _dt_nasc = value; }
        }

        public string Sexo
        {
            get { return _sexo; }
            set { _sexo = value; }
        }

        public string Foto
        {
            get { return _foto; }
            set { _foto = value; }
        }

        public int Ativo
        {
            get { return _ativo; }
            set { _ativo = value; }
        }

        #endregion


        #region "Construtores"

        //Construtor padrão
        public Pessoa()
        {
            Id_pessoa = 0;
            Nome = string.Empty;
            Email = string.Empty;
            Fone = string.Empty;
            Dt_nasc = string.Empty;
            Sexo = string.Empty;
            Foto = string.Empty;
            Ativo = 0;
        }

        //Construtor para inserir uma pessoa
        public Pessoa(string nome, string email, string fone,
                      string dt_nasc, string sexo, string foto,
                      int ativo)
        {
            Nome = nome;
            Email = email;
            Fone = fone;
            Dt_nasc = dt_nasc;
            Sexo = sexo;
            Foto = foto;
            Ativo = ativo;
        }


        //Construtor para alterar uma pessoa
        public Pessoa(int id_pessoa, string nome, string email, 
                      string fone,  string dt_nasc, string sexo)
        {
            Id_pessoa = id_pessoa;
            Nome = nome;
            Email = email;
            Fone = fone;
            Dt_nasc = dt_nasc;
            Sexo = sexo;
        }

        //Construtor para ativar/desativar uma pessoa
        public Pessoa(int id_pessoa, int ativo)
        {
            Id_pessoa = id_pessoa;
            Ativo = ativo;
        }


        //Construtor para alterar a foto de uma pessoa
        public Pessoa(int id_pessoa, string foto)
        {
            Id_pessoa = id_pessoa;
            Foto = foto;
        }

        #endregion



        #region "Métodos"

        //Método para inserir uma pessoa
        public void InserePessoa()
        {
            Conexao cn = new Conexao();
            try
            {
                cn.query = String.Format("INSERT INTO tab_pessoas(nome, email, fone," +
                    "dt_nasc, sexo, foto, ativo) VALUES('{0}', '{1}', '{2}', '{3}', " +
                    "'{4}', '{5}', {6})", Nome, Email, Fone, Dt_nasc, Sexo, Foto, Ativo);
                cn.comando = new SqlCommand(cn.query, cn.conexao);
                cn.AbreConexao();
                cn.comando.ExecuteNonQuery();
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                cn.FechaConexao();
            }
        }

        #endregion
    }
}
